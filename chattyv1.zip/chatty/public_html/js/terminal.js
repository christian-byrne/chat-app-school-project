/**
 * Browser Terminal Interactive Text Box
 * 
 * @author Christian P. Byrne
 * @exports Terminal
 * @implements
 * 
 * Default Shell Commands:
 * [cd] [color] [text] [darkmode] [lightmode] [echo]
 *
 * 
 */

import DB from "./db.js";

/**
 * Terminal class for a shell GUI.
 *
 * Add commands with addCommand method -- command should be anonymous
 * function that reads input text, calls this._parseArg() to check for
 * command name, executes, then returns input with HTML entities encoded.
 *
 * @param   {HTMLElement}    htmlNode    Node of the terminal in the document.
 * @param   {string}         user        Username.
 * @param   {string}         chat        Session name.
 * @param   {string}         prompt      Shell prompt.
 * @param   {string}         recipient   Chat partner.
 * @returns {Terminal}                  Terminal object.
 *
 * @extends DB
 *
 * @listens document#click
 * @listens document#keydown
 *
 *
 */
class Terminal {
  constructor(htmlNode, user, chat, prompt, recipient) {
    this.user = user;
    this.chat = chat;
    this.PS1 = prompt;
    this.recipient = recipient;

    this._node = htmlNode;
    this._titleBar = document.querySelector("p");
    this._stdin = this._node.querySelector("textarea");
    this._stdout = this._node.querySelector("div:nth-of-type(2) > div");
    this._msgLog = this._node.previousElementSibling;
    this._cwd = false;

    /** Return current prompt as HTML text. */
    this._getPrompt = () => {
      return `<span class="prompt-user">${this.user}@${this.recipient}:</span><span class="prompt-location">${this.chat}</span><span class="prompt-character">${this.PS1}</span>`;
    };

    /**
     * Arg parser for commands. Indicate if command name is in most recent
     * line. Optionally, return the positional arg after the command.
     *
     * @param    {innerHTML}      input     Teminal stdin text.
     * @param    {string}         command   Command name.
     * @param    {Boolean}        nargs     Parses positional arg if true,
     *                                        else just checks for command's
     *                                          presence.
     * @returns  {string|Boolean}           Arg.
     */
    this._parseArg = (input, command, nargs = false) => {
      const currLine = input.replace(/<br \/>/g, "").split(this._getPrompt());
      const currText = currLine[currLine.length - 2];
      if (currText && input[input.length - 2] == ">") {
        if (command == "decoded") {
          return currText.trim();
        }
        if (currText.includes(command)) {
          return !nargs ? true : currText.replace(command, "").trim();
        }
      }
    };

    /** All Commands' methods are applied to input text on keydown. So always return input */
    this.Commands = {
      /** Linebreak command replaces "\n" with "<br /> + prompt". */
      linebreak: (input) => {
        return input.replace(/\n/g, `<br />${this._getPrompt()} `);
      },
      /** Shell echo command. */
      echo: (input) => {
        const echoArg = this._parseArg(input, "echo", true);
        if (echoArg) {
          const popPrompt = input.substring(
            0,
            input.length + 1 - this._getPrompt().length
          );
          return `${popPrompt}<br />${echoArg}<br />    ${this._getPrompt()} `;
        }
        return input;
      },
      /** Print command list of shell. */
      help: (input) => {
        if (this._parseArg(input, "help")) {
          const helpDialog = `Example Commands:<br /><br />cd $LOCATION<br />color $COLOR<br />text $COLOR<br />darkmode<br />lightmode<br />echo $STRING`;
          const popPrompt = input.substring(
            0,
            input.length + 1 - this._getPrompt().length
          );
          return `${popPrompt}<br />${helpDialog}<br />${this._getPrompt()}`;
        }
        return input;
      },
      /** Change shell background. */
      color: (input) => {
        const colorArg = this._parseArg(input, "color", true);
        if (colorArg) {
          this._stdout.style.background = colorArg;
        }
        return input;
      },
      /** Change shell text color. */
      text: (input) => {
        const colorArg = this._parseArg(input, "text", true);
        if (colorArg) {
          this._stdout.style.color = colorArg;
        }
        return input;
      },
      /** Change shell theme to dark or light mode. */
      theme: (input) => {
        const resetBg = () => {
          this._stdout.setAttribute(
            "style",
            "background: var(--secondary-bg); color: var(--primary-text);"
          );
          document.documentElement.setAttribute("style", "filter: none");
        };
        if (this._parseArg(input, "lightmode")) {
          if (this._stdout.style.background === "white") {
            resetBg();
          } else {
            this._stdout.setAttribute(
              "style",
              "background: white; color: #121212;"
            );
            document.documentElement.setAttribute(
              "style",
              "filter: brightness(1.1) greyscale(.2);"
            );
          }
        }
        if (this._parseArg(input, "darkmode")) {
          if (this._stdout.style.background === "white") {
            resetBg();
          } else {
            this._stdout.setAttribute(
              "style",
              "background: white; color: #121212;"
            );
            document.documentElement.setAttribute(
              "style",
              "filter: invert(1);"
            );
          }
        }
        return input;
      },
      /** Change chatroom (change directory). */
      cd: (input) => {
        let chatArg = this._parseArg(input, "cd ", true);
        if (chatArg) {
          this.chat += `/${chatArg}`;
          this.cwd = true;
        }
        return input;
      },
    };
    /** Run all commands on input then echo output to display div (_stdout) */
    this._takeInput = () => {
      this.cwd = false;
      setTimeout(() => {
        let input = this._stdin.value;
        for (const command in this.Commands) {
          input = this.Commands[command](input);
        }
        const formatted =
          this._parseArg(input, "clear") || this.cwd ? "" : input;
        this._stdout.innerHTML = `${this._getPrompt()} ${formatted} `;
        this._stdin.value = decodeURI(formatted);
        const message = this._parseArg(formatted, "decoded");
        if (
          message &&
          !Object.keys(this.Commands).includes(message.split(" ")[0].trim())
        ) {
          DB.postMsg(this.user, message, this.chat);
        }
      }, 20);
    };
    /** Toggle on the CSS 'focus' class when textarea input is focused. */
    this.focus = () => {
      this._stdout.classList.add("focus");
    };
    /** Toggle off 'focus' CSS class when somewhere else is clicked */
    this.defocus = () => {
      if (this._stdin !== document.activeElement) {
        this._stdin.nextElementSibling.classList.remove("focus");
      }
    };
    /**
     * @param {string} name Any string, no spaces.
     * @param {(input) : input => {}} commandExecutor Function that takes input,
     *                                               parses a command, does
     *                                               something or edits the input,
     *                                               then returns the input
     */
    this.addCommand = (commandExecutor, name) => {
      this.Commands[name] = commandExecutor;
    };
    this._clear = () => {
      this._stdout.innerHTML = "";
      this._stdin.value = "";
      this._refresh();
    };
    this._refresh = (username = this.user) => {
      this._titleBar.innerHTML = `Message History ── ${this.user}@${this.recipient}:${this.chat}`;
      this._stdout.innerHTML = this._getPrompt();
    };
    /** Initialize with event listeners and session-specific text. */
    this.initialize = () => {
      this._stdin.addEventListener("keydown", this._takeInput);
      this._stdin.addEventListener("click", this.focus);
      document.documentElement.addEventListener("click", this.defocus);
      this._refresh();
    };
  }
}

export default Terminal;
