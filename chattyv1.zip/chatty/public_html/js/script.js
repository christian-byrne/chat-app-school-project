/**
 * Chatty app client script.
 * 
 * @author Christian P. Byrne
 */

import Terminal from "./terminal.js";
import DB from "./db.js";

/**
 * Refresher class for object that pings server on interval.
 */
class Refresher {
  constructor(contentBox, interval = 1, PS1 = "$", location = "~") {
    this.contentBox = contentBox;
    this._mostRecent = contentBox.children;
    function msgLine(message) {
      const div = document.createElement("div");
      div.innerHTML =
        `<span class="prompt-user">${message.alias}` +
        `@${message.at}:</span><span class="prompt` +
        `-location">${location}</span><span class="` +
        `prompt-character">${PS1}</span> ${message.content}`;
      return div;
    }
    this.currDepth = 0;
    setInterval(() => {
      DB.getLogs().then((logs) => {
        this._mostRecent = contentBox.children;
        let messages = Object.keys(logs);
        // Append new messages only to message history node.
        while (messages.length > this.currDepth) {
          this.contentBox.appendChild(msgLine(logs[messages[this.currDepth]]));
          this.currDepth += 1;
        }
      });
    }, Math.floor(interval * 1000));
  }
}

/**
 * Construct Terminal Function object and initialize it with user params.
 * @listens document#load
 */
window.onload = () => {

  // Construct Terminal instance.
  const terminalHTMLNode = document.querySelector("div.term");
  const chatNode = new Terminal(terminalHTMLNode, "alias", "~", "$", "ubuntu");
  chatNode.initialize();
  chatNode.focus();
  /** Listener structure. */
  document.addEventListener("click", function (event) {
    const node = event.target;

    // Submit-new-alias-button listener.
    if (node.getAttribute("type") == "button") {
      const newAlias = document.querySelector("input[type=text]").value;
      chatNode.user = newAlias;
      chatNode.refresh();
      document.querySelector("input[type=text]").value = "";
    }

    // X button in shell clears it.
    if (node == document.querySelector("button:nth-of-type(1)")) {
      chatNode.clear();
    }
  });

  // Initialize set-interval server ping object.
  new Refresher(
    document.querySelector("div.msg > div:nth-of-type(2)")
  );
};
