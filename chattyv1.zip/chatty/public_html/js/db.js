/**
 * DB Mutations for Internal MongoDB Server.
 * @author Christian P. Byrne
 *
 * @exports object
 * 
 * 
 */

const DB = {
  /**
   * Get all message logs.
   * @returns {Promise<{id: string, alias: string, at: string, chat: string}[]>}
   */
  getLogs: async () => {
    let ret = await $.get("http://143.198.57.139:80/logs", (data) => {
      console.log(data);
    }).then((value) => {
      return value;
    });
    return ret;
  },
  searchHistory: async (depth) => {
  /**
   * Get all message logs.
   * @param   {number}  depth - Number of messages back to go.
   * @returns {Promise<{id: string, alias: string, at: string, chat: string}[]>}
   * 
   */
    await $.get(`http://143.198.57.139:80/logs?depth=${depth}`, (data) => {
      return data;
    });
  },
  /**
   * Update DB with message.
   * @param {string} alias   - Username of sender.
   * @param {string} content - Text of the message.
   * @param {string} at      - Message recipient.
   */
  postMsg: (alias, content, at) => {
    $.get(
      `http://143.198.57.139:80/msg/${encodeURI(alias)}/${encodeURI(
        content
      )}/${encodeURI(at)}`
    );
  },
};
export default DB;
