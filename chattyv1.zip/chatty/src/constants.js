"use strict";
exports.__esModule = true;
exports.__prod__ = process.env.NODE_ENV === "production";
